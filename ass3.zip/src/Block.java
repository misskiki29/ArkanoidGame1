import biuoop.DrawSurface;

import java.awt.Color;
/**
 * A rectangular block that can be drawn on the screen and collided with.
 * A block has a rectangle shape and a color, and implements both
 * {@link Collidable} and {@link Sprite}.
 */
public class Block implements Collidable, Sprite {
    private Rectangle rect;
    private Color color;
    /**
     * Creates a block with the given rectangle and color.
     *
     * @param rect  the block's collision rectangle.
     * @param color the block's fill color.
     */
    public Block(Rectangle rect, Color color) {
        this.rect = rect;
        this.color = color;
    }

    @Override
    public void timePassed() {
        return;
    }

    @Override
    public Rectangle getCollisionRectangle() {
        return this.rect;
    }

    @Override
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        double dx = currentVelocity.getDx();
        double dy = currentVelocity.getDy();

        double leftX = rect.getUpperLeft().getX();
        double rightX = leftX + rect.getWidth();
        double topY = rect.getUpperLeft().getY();
        double bottomY = topY + rect.getHeight();
        if (DoublesCompare.equals(collisionPoint.getX(), leftX)
                || DoublesCompare.equals(collisionPoint.getX(), rightX)) {
            dx = -dx;
        }
        if (DoublesCompare.equals(collisionPoint.getY(), topY)
                || DoublesCompare.equals(collisionPoint.getY(), bottomY)) {
            dy = -dy;
        }
        return new Velocity(dx, dy);
    }

    /**
     * Draws the block on the given draw surface.
     *
     * @param d the surface on which the block should be drawn.
     */
    @Override
    public void drawOn(DrawSurface d) {
        d.setColor(this.color);
        int x = (int) this.rect.getUpperLeft().getX();
        int y = (int) this.rect.getUpperLeft().getY();
        int w = (int) this.rect.getWidth();
        int h = (int) this.rect.getHeight();
        d.fillRectangle(x, y, w, h);
        d.setColor(Color.BLACK);
        d.drawRectangle(x, y, w, h);
    }

    @Override
    public void addToGame(Game g) {
        g.addSprite(this);
        g.addCollidable(this);
    }
}
