//ID 230360703
//Name: Daria Lozinskaya

import biuoop.GUI;
import biuoop.DrawSurface;

import java.util.Random;
import java.awt.Color;

/**
 * The {@code AbstractArtDrawing} class generates and visualizes an abstract
 * geometric composition by drawing random lines and marking their intersections.
 *
 * <p>
 * This class demonstrates basic use of the {@link biuoop.GUI} and
 * {@link biuoop.DrawSurface} classes to create graphical output.
 * It supports drawing:
 * <ul>
 *   <li>Random black lines</li>
 *   <li>Blue points marking midpoints of lines</li>
 *   <li>Red points marking intersections of lines</li>
 *   <li>Green triangles formed where three lines intersect</li>
 * </ul>
 * </p>
 *
 * <p>It relies on the {@link Line} and {@link Point} classes for geometric
 * calculations such as intersections and midpoints.</p>
 *
 * @author Daria
 * @since 2025-11-04
 */

public class AbstractArtDrawing {
    /**
     * An array containing all generated lines.
     */
    private static final Line[] LINES = new Line[10];

    /**
     * Draws ten random lines on the provided drawing surface.
     * Each line has random start and end coordinates within the GUI window.
     *
     * @param gui the GUI object controlling the drawing window.
     * @param d   the drawing surface to draw on.
     */
    public void drawRandomLines(GUI gui, DrawSurface d) {
        Random rand = new Random();
        for (int i = 0; i < LINES.length; i++) {
            int x1 = rand.nextInt(400) + 1;
            int y1 = rand.nextInt(300) + 1;
            int x2 = rand.nextInt(400) + 1;
            int y2 = rand.nextInt(300) + 1;
            d.setColor(Color.BLACK);
            d.drawLine(x1, y1, x2, y2);
            Line line = new Line(x1, y1, x2, y2);
            LINES[i] = line;
        }
    }

    /**
     * Draws small blue circles at the midpoint of each line.
     *
     * @param gui the GUI object controlling the drawing window.
     * @param d   the drawing surface to draw on.
     */
    public void drawMiddlePoints(GUI gui, DrawSurface d) {
        d.setColor(Color.BLUE);
        for (int i = 0; i < LINES.length; i++) {

            d.fillCircle((int) LINES[i].middle().getX(), (int) LINES[i].middle().getY(), 3);
        }
    }

    /**
     * Draws red circles at the intersection points of all pairs of lines.
     *
     * <p>
     * The method checks all unique line pairs (i, j) where {@code i < j}
     * and marks their intersection on the drawing surface if it exists.
     * </p>
     *
     * @param gui the GUI object controlling the drawing window.
     * @param d   the drawing surface to draw on.
     */
    public void drawIntersectionPoints(GUI gui, DrawSurface d) {
        d.setColor(Color.RED);
        for (int i = 0; i < LINES.length; i++) {
            for (int j = i + 1; j < LINES.length; j++) {
                Point p = LINES[i].intersectionWith(LINES[j]);
                if (p != null) {
                    int x = (int) Math.round(p.getX());
                    int y = (int) Math.round(p.getY());
                    if (x >= 0 && x < d.getWidth() && y >= 0 && y < d.getHeight()) {
                        d.fillCircle(x, y, 3);
                    }
                }
            }
        }
    }

    /**
     * Draws green triangles at locations where three lines intersect pairwise.
     *
     * <p>
     * For every unique triple of lines (i, j, k), this method checks if all
     * three intersect pairwise (i.e., form a closed triangle), and if so,
     * draws the triangle by connecting the intersection points.
     * </p>
     *
     * @param gui the GUI object controlling the drawing window.
     * @param d   the drawing surface to draw on.
     */
    public void drawIntersectionTriangles(GUI gui, DrawSurface d) {
        d.setColor(Color.GREEN);
        for (int i = 0; i < LINES.length; i++) {
            for (int j = i + 1; j < LINES.length; j++) {
                if (!LINES[i].isIntersecting(LINES[j])) {
                    continue;
                }
                for (int k = j + 1; k < LINES.length; k++) {
                    if (LINES[i].isThreeIntersecting(LINES[j], LINES[k])) {
                        //Drawing line 1
                        int x1 = (int) LINES[i].intersectionWith(LINES[j]).getX();
                        int y1 = (int) LINES[i].intersectionWith(LINES[j]).getY();
                        int x2 = (int) LINES[i].intersectionWith(LINES[k]).getX();
                        int y2 = (int) LINES[i].intersectionWith(LINES[k]).getY();
                        d.drawLine(x1, y1, x2, y2);
                        //Drawing line 2
                        x1 = (int) LINES[i].intersectionWith(LINES[k]).getX();
                        y1 = (int) LINES[i].intersectionWith(LINES[k]).getY();
                        x2 = (int) LINES[j].intersectionWith(LINES[k]).getX();
                        y2 = (int) LINES[j].intersectionWith(LINES[k]).getY();
                        d.drawLine(x1, y1, x2, y2);
                        //Drawing line 3
                        x1 = (int) LINES[i].intersectionWith(LINES[j]).getX();
                        y1 = (int) LINES[i].intersectionWith(LINES[j]).getY();
                        x2 = (int) LINES[j].intersectionWith(LINES[k]).getX();
                        y2 = (int) LINES[j].intersectionWith(LINES[k]).getY();
                        d.drawLine(x1, y1, x2, y2);
                    }
                }
            }
        }
    }

    /**
     * Main entry point of the program.
     *
     * <p>
     * Creates a GUI window, draws 10 random lines, marks their midpoints
     * and intersection points, and draws green triangles where three lines intersect.
     * </p>
     *
     * @param args command-line arguments (not used).
     */
    public static void main(String[] args) {
        AbstractArtDrawing art = new AbstractArtDrawing();
        GUI gui = new GUI("Lines Intersection", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        art.drawRandomLines(gui, d);
        art.drawMiddlePoints(gui, d);
        art.drawIntersectionPoints(gui, d);
        art.drawIntersectionTriangles(gui, d);
        gui.show(d);
    }

}
