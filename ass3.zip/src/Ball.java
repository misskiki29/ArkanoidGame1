import biuoop.DrawSurface;

import java.awt.Color;

/**
 * The {@code Ball} class represents a ball with a center point, radius,
 * color and velocity, that can be drawn on a {@link DrawSurface} and moved
 * step by step inside different movement "frames".
 *
 * <p>
 *
 * <p>
 * A ball can be configured to:
 * <ul>
 *     <li>Move and bounce inside the full window frame.</li>
 *     <li>Move and bounce only inside the grey rectangle
 *         (from (50,50) to (500,500)), and also bounce off the overlapping
 *         area with the yellow rectangle.</li>
 *     <li>Move and bounce only outside both rectangles (grey and yellow).</li>
 * </ul>
 * The behavior is controlled by the flags {@link #insideGreyRec} and
 * {@link #outsideRects}.
 */
public class Ball implements Sprite {
    /**
     * The center of the ball.
     */
    private Point center;
    /**
     * The radius of the ball.
     */
    private int r;
    private Color color;
    /**
     * The color of the ball.
     */
    private Velocity velocity;
    /** The current velocity of the ball. */
    /**
     * Flag indicating that this ball should move only inside
     * the grey rectangle (and bounce off its borders and the
     * intersection with the yellow rectangle).
     */
    private boolean insideGreyRec;
    /**
     * Flag indicating that this ball should move only outside both
     * the grey and yellow rectangles, bouncing on their borders and
     * on the window frame borders.
     */
    private boolean outsideRects;
    private GameEnvironment gameEnvironment;
    /**
     * The full window width.
     */
    static final double WIDTH = 800;
    /**
     * The full window height.
     */
    static final double HEIGHT = 600;
    /**
     * The starting (left/top) coordinate of the grey rectangle.
     */
    static final double GREYRECTANGLESTART = 50;
    /**
     * The ending (right/bottom) coordinate of the grey rectangle.
     */
    static final double GREYRECTANGLEFINISH = 500;
    /**
     * The starting (left/top) coordinate of the yellow rectangle.
     */
    static final double YELLOWRECTANGLESTART = 450;
    /**
     * The ending (right/bottom) coordinate of the yellow rectangle.
     */
    static final double YELLOWRECTANGLEFINISH = 600;

    /**
     * Constructs a new ball with the given center, radius and color.
     *
     * @param center the center point of the ball.
     * @param r      the radius of the ball.
     * @param color  the color of the ball.
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.center = new Point(center.getX(), center.getY());
        this.r = r;
        this.color = color;
    }

    @Override
    public void timePassed() {
        moveOneStep();
    }

    @Override
    public void addToGame(Game g) {
        g.addSprite(this);
        this.setGameEnvironment(g.getEnvironment());
    }

    /**
     * Draws the ball on the given draw surface.
     *
     * @param surface the surface on which the ball should be drawn.
     */
    @Override
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.getColor());
        surface.fillCircle(this.getX(), this.getY(), this.getSize());
    }

    /**
     * Sets whether this ball should move only inside the grey rectangle.
     *
     * @param value {@code true} if the ball should be constrained to the
     *              grey rectangle; {@code false} otherwise.
     */
    public void setInsideGreyRec(boolean value) {
        this.insideGreyRec = value;
    }

    /**
     * Sets whether this ball should move only outside the grey and yellow
     * rectangles.
     *
     * @param value {@code true} if the ball should be constrained to move
     *              only outside both rectangles; {@code false} otherwise.
     */

    public void setOutsideRects(boolean value) {
        this.outsideRects = value;
    }
    /**
     * Sets the game environment in which this ball moves.
     *
     * @param gameEnvironment the environment containing all collidable objects.
     */
    public void setGameEnvironment(GameEnvironment gameEnvironment) {
        this.gameEnvironment = gameEnvironment;
    }

    /**
     * Returns the x-coordinate of the center of the ball as an integer.
     *
     * @return the x-coordinate of the ball's center.
     */
    // accessors
    public int getX() {
        return (int) center.getX();
    }

    /**
     * Returns the y-coordinate of the center of the ball as an integer.
     *
     * @return the y-coordinate of the ball's center.
     */
    public int getY() {
        return (int) center.getY();
    }

    /**
     * Returns the radius (size) of the ball.
     *
     * @return the radius of the ball.
     */
    public int getSize() {
        return this.r;
    }

    /**
     * Returns the color of the ball.
     *
     * @return the ball's color.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * Sets the ball's velocity to the given velocity object. The velocity
     * is copied so that future changes to the given {@link Velocity}
     * instance do not affect the ball.
     *
     * @param v the velocity to set.
     */
    public void setVelocity(Velocity v) {
        this.velocity = new Velocity(v.getDx(), v.getDy());
    }

    /**
     * Sets the ball's velocity using the given dx and dy components.
     *
     * @param dx the horizontal component of the velocity.
     * @param dy the vertical component of the velocity.
     */

    public void setVelocity(double dx, double dy) {
        this.velocity = new Velocity(dx, dy);
    }

    /**
     * Returns a copy of the ball's current velocity.
     *
     * @return the current velocity of the ball.
     */
    public Velocity getVelocity() {
        return new Velocity(this.velocity.getDx(), this.velocity.getDy());
    }

    /**
     * Moves the ball one step inside the full window frame (0,0)-(WIDTH,HEIGHT),
     * bouncing it off the window borders when the ball reaches them.
     *
     * @param nextX the predicted next x-coordinate of the center.
     * @param nextY the predicted next y-coordinate of the center.
     */
    private void moveInFullFrame(double nextX, double nextY) {
        double x = nextX;
        double y = nextY;

        if (DoublesCompare.lessOrEquals(x - this.r, 0) || DoublesCompare.greaterOrEquals(x + this.r, WIDTH)) {
            this.velocity = new Velocity(-velocity.getDx(), velocity.getDy());
            x = this.center.getX() + this.velocity.getDx();
        }
        if (DoublesCompare.lessOrEquals(y - this.r, 0) || DoublesCompare.greaterOrEquals(y + this.r, HEIGHT)) {
            this.velocity = new Velocity(velocity.getDx(), -velocity.getDy());
            y = this.center.getY() + this.velocity.getDy();
        }
        this.center = new Point(x, y);
    }

    /**
     * Returns true if this ball (as a circle) overlaps the given axis-aligned
     * rectangle defined by its left, right, top, and bottom edges.
     *
     * <p>
     * The check takes the ball's radius into account, so it becomes true as soon
     * as the border of the ball touches or crosses the rectangle.
     *
     * @param x      predicted center x.
     * @param y      predicted center y.
     * @param left   rectangle left edge.
     * @param right  rectangle right edge.
     * @param top    rectangle top edge.
     * @param bottom rectangle bottom edge.
     * @return true if the ball overlaps the rectangle; false otherwise.
     */
    private boolean overlapsRect(double x, double y,
                                 double left, double right,
                                 double top, double bottom) {
        return DoublesCompare.greater(x + this.r, left)
                && DoublesCompare.less(x - this.r, right)
                && DoublesCompare.greater(y + this.r, top)
                && DoublesCompare.less(y - this.r, bottom);
    }

    /**
     * Moves the ball one step while it is constrained to the grey rectangle
     * (from (50,50) to (500,500)). The ball bounces off the borders of the
     * grey rectangle and also bounces when it tries to enter the intersection
     * area with the yellow rectangle.
     *
     * @param nextX the predicted next x-coordinate of the center.
     * @param nextY the predicted next y-coordinate of the center.
     */
    private void moveInsideGrey(double nextX, double nextY) {
        //Grey frame: (50,50) -(500,500)
        double left = GREYRECTANGLESTART + this.r;
        double right = GREYRECTANGLEFINISH - this.r;
        double top = GREYRECTANGLESTART + this.r;
        double bottom = GREYRECTANGLEFINISH - this.r;

        double x = nextX;
        double y = nextY;
        //bounce on grey rec borders
        if (DoublesCompare.less(x, left) || DoublesCompare.greater(x, right)) {
            this.velocity = new Velocity(-velocity.getDx(), velocity.getDy());
            x = this.center.getX() + this.velocity.getDx();
        }
        if (DoublesCompare.less(y, top) || DoublesCompare.greater(y, bottom)) {
            this.velocity = new Velocity(velocity.getDx(), -velocity.getDy());
            y = this.center.getY() + this.velocity.getDy();
        }
        //Make sure the ball does not intersect with yellow rectangle

        boolean overlapsYellow = overlapsRect(
                x, y,
                YELLOWRECTANGLESTART, YELLOWRECTANGLEFINISH,
                YELLOWRECTANGLESTART, YELLOWRECTANGLEFINISH);
//        double interLeft = YELLOWRECTANGLESTART + this.r;
//        double interRight = GREYRECTANGLEFINISH - this.r;
//        double interTop = YELLOWRECTANGLESTART + this.r;
//        double interBottom = GREYRECTANGLEFINISH - this.r;
//        boolean hitIntersection = DoublesCompare.greaterOrEquals(x, interLeft)
//                && DoublesCompare.lessOrEquals(x, interRight)
//                && DoublesCompare.greaterOrEquals(y, interTop)
//                && DoublesCompare.lessOrEquals(y, interBottom);
        if (overlapsYellow) {
            this.velocity = new Velocity(-velocity.getDx(), -velocity.getDy());
        } else {
            this.center = new Point(x, y);
        }
    }

    /**
     * Moves the ball one step while it is constrained to move only outside
     * the grey and yellow rectangles. The ball bounces on the window borders
     * and also bounces when it touches or enters either of the rectangles.
     *
     * @param nextX the predicted next x-coordinate of the center.
     * @param nextY the predicted next y-coordinate of the center.
     */
    private void moveOutsideRects(double nextX, double nextY) {
        //frame borders
        double x = nextX;
        double y = nextY;

        //bounce on frame borders
        if (DoublesCompare.lessOrEquals(x - this.r, 0) || DoublesCompare.greaterOrEquals(x + this.r, WIDTH)) {
            this.velocity = new Velocity(-velocity.getDx(), velocity.getDy());
            x = this.center.getX() + this.velocity.getDx();
        }
        if (DoublesCompare.lessOrEquals(y - this.r, 0) || DoublesCompare.greaterOrEquals(y + this.r, HEIGHT)) {
            this.velocity = new Velocity(velocity.getDx(), -velocity.getDy());
            y = this.center.getY() + this.velocity.getDy();
        }

        //we can't move inside grey and yellow triangles
        boolean overlapsGrey = overlapsRect(x, y, GREYRECTANGLESTART, GREYRECTANGLEFINISH,
                GREYRECTANGLESTART, GREYRECTANGLEFINISH);
        boolean overlapsYellow = overlapsRect(
                x, y,
                YELLOWRECTANGLESTART, YELLOWRECTANGLEFINISH,
                YELLOWRECTANGLESTART, YELLOWRECTANGLEFINISH);
        if (overlapsGrey || overlapsYellow) {
            this.velocity = new Velocity(-velocity.getDx(), -velocity.getDy());
        } else {
            this.center = new Point(x, y);
        }
    }

    /**
     * Moves the ball one step according to its current velocity and movement
     * mode.
     * If {@link #insideGreyRec} is {@code true}, the ball is moved using
     * {@link #moveInsideGrey(double, double)}. If {@link #outsideRects} is
     * {@code true}, the ball is moved using
     * {@link #moveOutsideRects(double, double)}. Otherwise, the ball moves
     * inside the full window frame using
     * {@link #moveInFullFrame(double, double)}.
     */

    public void moveOneStep() {
        Point nextCenter = this.velocity.applyToPoint(this.center);
        Line trajectory = new Line(this.center, nextCenter);

        CollisionInfo info = this.gameEnvironment.getClosestCollision(trajectory);
        //If there are no collisions on this trajectory
        // then move the ball to the end of trajectory
        if (info == null) {
            this.center = nextCenter;
            return;
        }
        //If there is a collision on trajectory, there is a hit
        Point collisionPoint = info.collisionPoint();
        Collidable obj = info.collisionObject();

        //we will use epsilon to move the ball to the hit point
        //but slightly before, epsilon is this "slightly"
        double epsilon = 0.0001;
        double newX = this.center.getX();
        double newY = this.center.getY();

        double dx = this.velocity.getDx();
        double dy = this.velocity.getDy();

        if (dx > 0) {
            newX = collisionPoint.getX() - epsilon;
        } else if (dx < 0) {
            newX = collisionPoint.getX() + epsilon;
        } else {
            newX = collisionPoint.getX();
        }

        if (dy > 0) {
            newY = collisionPoint.getY() - epsilon;
        } else if (dy < 0) {
            newY = collisionPoint.getY() + epsilon;
        } else {
            newY = collisionPoint.getY();
        }
        this.center = new Point(newX, newY);

        this.velocity = obj.hit(collisionPoint, this.velocity);

    }
}

