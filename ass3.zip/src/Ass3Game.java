/**
 * Entry point for Assignment 3.
 * Creates a game, initializes it, and starts the animation loop.
 */
public class Ass3Game {
    /**
     * Launches the game.
     *
     * @param args unused command-line arguments
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
